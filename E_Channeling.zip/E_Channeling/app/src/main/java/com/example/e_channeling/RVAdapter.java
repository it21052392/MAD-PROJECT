package com.example.e_channeling;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.Holder;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.MyViewHolder> {

    Context context;
    ArrayList<Prescription> list;


    public RVAdapter(Context context, ArrayList<Prescription> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public RVAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.ordered_prescription,parent,false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder,final int position) {
    Prescription p = list.get(position);
    holder.pname.setText("Name - " + p.getName());
    holder.paddress.setText("Address - " + p.getAddress());
    holder.pphone.setText("Tel - " + p.getNumber());



    holder.btnEdit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final DialogPlus dialogPlus = DialogPlus.newDialog(holder.pname.getContext())
                    .setContentHolder(new ViewHolder(R.layout.update_popup))
                    .setExpanded(true,1500).create();

            //dialogPlus.show();

            View view1 = dialogPlus.getHolderView();
            EditText name = view1.findViewById(R.id.txtName);
            EditText address = view1.findViewById(R.id.txtAddress);
            EditText phone = view1.findViewById(R.id.txtPhone);
            EditText surl = view1.findViewById(R.id.txtPhoto);

            Button btnUpdate = view1.findViewById(R.id.btnUpdate);

            name.setText(p.getName());
            address.setText(p.getAddress());
            phone.setText(p.getNumber());
            surl.setText(p.getSurl());

            dialogPlus.show();

           btnUpdate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Map<String,Object> map = new HashMap<>();
                    map.put("name",name.getText().toString());
                    map.put("address", address.getText().toString());
                    map.put("number",phone.getText().toString());
                    map.put("surl",surl.getText().toString());

                    //String postKey = databaseReference.getRef(position).getKey();
                    FirebaseDatabase.getInstance().getReference().child("Prescription").child(String.valueOf(position))
                            .updateChildren(map)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(holder.pname.getContext(), "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                                    dialogPlus.dismiss();

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(holder.pname.getContext(), "Error While Updateing", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            });
        }
    });

    holder.btnDelete.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            AlertDialog.Builder builder = new AlertDialog.Builder(holder.pname.getContext());
            builder.setTitle("Are you sure?");
            builder.setMessage("Deleted data can't be Undo.");


            builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    FirebaseDatabase.getInstance().getReference().child("Prescription").child(String.valueOf(position)).removeValue();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Toast.makeText(holder.pname.getContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                }
            });
            builder.show();
        }
    });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView pname,paddress,pphone;

        Button btnEdit,btnDelete;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            pname = itemView.findViewById(R.id.patient_name);
            paddress = itemView.findViewById(R.id.patient_address);
            pphone = itemView.findViewById(R.id.patient_phone);
            btnEdit = itemView.findViewById(R.id.editbtn);
            btnDelete = itemView.findViewById(R.id.deletebtn);
        }
    }
}
