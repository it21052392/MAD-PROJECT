package com.example.e_channeling;

public class user {
    public String name,email,password,age;

    public user(){

    }

    public user(String name, String email, String password, String age) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.age = age;
    }
}
