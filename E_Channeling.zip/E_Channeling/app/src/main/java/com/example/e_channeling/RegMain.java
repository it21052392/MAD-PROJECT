package com.example.e_channeling;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RegMain extends AppCompatActivity implements View.OnClickListener{
    TextView register;
    @Override
    public void onClick(View view) {
        register = findViewById(R.id.register);
        register.setOnClickListener(this);
        switch (view.getId()){
            case R.id.register:
                startActivity(new Intent(this,RegistrationUser.class));
                break;
        }
    }
}
