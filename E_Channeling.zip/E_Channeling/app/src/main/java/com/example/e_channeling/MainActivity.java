package com.example.e_channeling;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText name = findViewById(R.id.inpt_name);
        EditText address = findViewById(R.id.inpt_address);
        EditText number = findViewById(R.id.inpt_phone);
        EditText surl = findViewById(R.id.url);

        Button btn = findViewById(R.id.btn);
        DAOPrescription daop = new DAOPrescription();



        btn.setOnClickListener(view -> {
            Prescription p = new Prescription(name.getText().toString(),address.getText().toString(),number.getText().toString(),surl.getText().toString());
            daop.add(p).addOnSuccessListener(suc->{
                Toast.makeText(this, "Prescription ordered successfully", Toast.LENGTH_LONG).show();
            }).addOnFailureListener(er ->{
                Toast.makeText(this, ""+er.getMessage(), Toast.LENGTH_LONG).show();
            });
        });




    }


}
